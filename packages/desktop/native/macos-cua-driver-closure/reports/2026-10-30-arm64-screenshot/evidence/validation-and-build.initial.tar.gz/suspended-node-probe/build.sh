#!/bin/sh
set -eu

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../../.." && pwd)
OUT="$ROOT/output/cua-arm64-screenshot/suspended-node-probe"
SDK="/Library/Developer/CommandLineTools/SDKs/MacOSX27.0.sdk"
R11="$ROOT/packages/desktop/native/macos-cua-helper-round11/src"

/usr/bin/clang++ \
  -std=c++17 \
  -fobjc-arc \
  -arch arm64 \
  -isysroot "$SDK" \
  -mmacosx-version-min=14.2 \
  -O2 \
  -Wall \
  -Wextra \
  -Werror \
  -I "$R11" \
  "$OUT/suspended_node_probe.mm" \
  "$R11/r11_self_identity.mm" \
  -framework Foundation \
  -framework Security \
  -o "$OUT/suspended-node-probe"

/usr/bin/clang++ \
  -std=c++17 \
  -arch arm64 \
  -isysroot "$SDK" \
  -mmacosx-version-min=14.2 \
  -O2 \
  -Wall \
  -Wextra \
  -Werror \
  "$OUT/negative_marker.cpp" \
  -o "$OUT/negative-marker"

/usr/bin/file "$OUT/suspended-node-probe" "$OUT/negative-marker"
/usr/bin/lipo -archs "$OUT/suspended-node-probe"
