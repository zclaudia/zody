#!/bin/sh
set -eu

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../../.." && pwd)
exec "$ROOT/output/cua-arm64-screenshot/suspended-node-probe/suspended-node-probe" \
  "$ROOT/output/cua-helper-round11/controller-signed/candidate/helper/Zody CUA Helper Round11.app/Contents/Resources/node" \
  "$ROOT/output/cua-helper-round11/controller-signed/identity-pins.json"
