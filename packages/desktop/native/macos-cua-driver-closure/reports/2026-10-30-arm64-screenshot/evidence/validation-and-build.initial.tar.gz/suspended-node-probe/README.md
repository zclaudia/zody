# Suspended Node Loaded-Code Probe

This directory is an isolated front-gate probe. It does not modify production source, specs, older reports, older output, the default toolchain, signing state, certificates, or UI.

## What it does

`suspended-node-probe <target-executable> <identity-pins.json>`:

1. Reads `nodeIdentifier`, `nodeLeafSha256`, `nodeDesignatedRequirement`, and `nodeCdhash` from the pins JSON.
2. Calls `posix_spawn` with `POSIX_SPAWN_START_SUSPENDED | POSIX_SPAWN_CLOEXEC_DEFAULT` and pipes for stdin/stdout/stderr.
3. Confirms the real PID is stopped by bounded polling of `proc_pidinfo(PROC_PIDTBSDINFO).pbi_status == SSTOP`, including PID start-time evidence.
4. Calls the existing function directly from `packages/desktop/native/macos-cua-helper-round11/src/r11_self_identity.mm`:

   ```cpp
   zody::cua::round11::LoadedCodeResult
   verify_loaded_code_for_pid(pid_t pid, const LoadedCodeExpectation& expected);
   ```

5. Records the function's designated requirement, CDHash, leaf/identifier matches, flags, and entitlement result. It also performs a separate entitlement-dictionary read and records the actual JSON or absence.
6. Sends `SIGCONT` only after the loaded-code gate accepts. It then writes exactly `console.log(42)\n` to stdin, closes stdin, reads the child pipes, and requires exit code `0`, stdout exactly `42\n`, and empty stderr.

## Suspend/status research

- `posix_spawnattr_setflags(3)` and `<sys/spawn.h>` document `POSIX_SPAWN_START_SUSPENDED`: the child is created as if it immediately received `SIGSTOP`, and `SIGCONT` is required to continue.
- `<sys/wait.h>` exposes `WUNTRACED`, but the probe does not use it. A blocking `waitpid(..., WUNTRACED)` can wait indefinitely, and the gate does not need a stop notification. The probe uses the kernel's process state directly through bounded `proc_pidinfo(PROC_PIDTBSDINFO)` polling instead.
- All terminal reaping uses `waitpid(pid, ..., WNOHANG)` only. No unbounded wait and no `WUNTRACED` wait are used.
- Bounds: suspend detection `3000 ms`, stdin write `3000 ms`, child output `5000 ms`, normal child reap `5000 ms`, each cleanup reap `2000 ms` (at most three SIGKILL attempts).

## Build

Run from the repository root:

```sh
./output/cua-arm64-screenshot/suspended-node-probe/build.sh
```

The script uses the frozen SDK `/Library/Developer/CommandLineTools/SDKs/MacOSX27.0.sdk`, `arm64`, minimum macOS `14.2`, and links `Foundation` and `Security`. It compiles the existing identity implementation rather than copying it.

The arm64 linker adds an ad-hoc code signature by default. This is neither a certificate identity nor the pinned Node identity. No `codesign`, certificate generation, certificate installation, or toolchain change is performed.

## Positive command

```sh
cd /Users/zhvala/SourceCode/zody
./output/cua-arm64-screenshot/suspended-node-probe/run-positive.sh \
  > output/cua-arm64-screenshot/suspended-node-probe/positive-run.json
```

The fixed target is:

```text
output/cua-helper-round11/controller-signed/candidate/helper/Zody CUA Helper Round11.app/Contents/Resources/node
```

The pins are:

```text
output/cua-helper-round11/controller-signed/identity-pins.json
```

A real success requires all of the following in the emitted JSON:

```text
ok == true
spawn.spawned == true
suspended.detected == true
verification.accepted == true
verification.loadedCode.reason == "accepted"
resume.sigcontSent == true
stdin.sent == true
child.stdout == "42\n"
child.stderr == ""
child.wait.exited == true
child.wait.exitCode == 0
child.reaped == true
```

## Negative command

`negative_marker.cpp` is a local marker fixture. It is runnable and is not the pinned identity. It attempts to create:

```text
output/cua-arm64-screenshot/suspended-node-probe/negative-marker-fired
```

```sh
cd /Users/zhvala/SourceCode/zody
./output/cua-arm64-screenshot/suspended-node-probe/run-negative.sh
```

The script requires a nonzero probe exit and requires the marker to be absent. The expected JSON evidence is:

```text
ok == false
verification.accepted == false
resume.sigcontSent == false
child.stdout == ""
failureCleanup.attempted == true
failureCleanup.reaped == true
```

A system-binary negative is also valid:

```sh
cd /Users/zhvala/SourceCode/zody
set +e
./output/cua-arm64-screenshot/suspended-node-probe/suspended-node-probe \
  /usr/bin/true \
  output/cua-helper-round11/controller-signed/identity-pins.json \
  > output/cua-arm64-screenshot/suspended-node-probe/negative-system.json
STATUS=$?
set -e
test "$STATUS" -ne 0
```

## Evidence boundaries

- The identity gate is the existing `verify_loaded_code_for_pid` result plus a successful entitlement query. The top-level `ok` is not inferred from spawn success or `SIGCONT` success.
- `target.sha256` is evidence of the bytes passed to the probe. It is not an additional pin because `identity-pins.json` contains no resource hash.
- `suspended.detected` comes from `proc_pidinfo`, not from an assumed `waitpid` stop event.
- On every post-spawn failure, the probe sends `SIGKILL` and performs bounded reaping. If reaping cannot be confirmed, the JSON reports `failureCleanup.reaped == false` and the process exits nonzero; it never reports success.
- This worker compiled the probe and fixture but did not execute either. No positive or negative success claim is made here. The controller must run the commands and inspect the actual JSON.

## Files

```text
suspended_node_probe.mm  probe source
negative_marker.cpp      negative marker fixture source
build.sh                 frozen-SDK build command
run-positive.sh          fixed Node and pins command
run-negative.sh          marker negative command
suspended-node-probe     compiled arm64 probe
negative-marker          compiled arm64 negative fixture
```
