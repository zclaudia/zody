#include <fcntl.h>
#include <unistd.h>

int main() {
  constexpr char kMarker[] =
      "/Users/zhvala/SourceCode/zody/output/cua-arm64-screenshot/"
      "suspended-node-probe/negative-marker-fired";
  const int fd = open(kMarker, O_WRONLY | O_CREAT | O_EXCL | O_CLOEXEC, 0600);
  if (fd < 0) return 64;
  constexpr char kText[] = "executed\n";
  const ssize_t written = write(fd, kText, sizeof(kText) - 1);
  const int close_result = close(fd);
  if (written != static_cast<ssize_t>(sizeof(kText) - 1)) return 65;
  if (close_result != 0) return 66;
  return 0;
}
