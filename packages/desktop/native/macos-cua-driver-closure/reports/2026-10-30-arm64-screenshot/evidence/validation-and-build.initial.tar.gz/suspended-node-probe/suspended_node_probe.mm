#import <CommonCrypto/CommonDigest.h>
#import <Foundation/Foundation.h>
#import <Security/Security.h>

#include <fcntl.h>
#include <libproc.h>
#include <poll.h>
#include <signal.h>
#include <spawn.h>
#include <sys/proc.h>
#include <sys/proc_info.h>
#include <sys/spawn.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

#include <algorithm>
#include <array>
#include <cctype>
#include <cerrno>
#include <chrono>
#include <climits>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <string>
#include <utility>

#include "r11_self_identity.h"

namespace {

using Clock = std::chrono::steady_clock;
using zody::cua::round11::LoadedCodeExpectation;
using zody::cua::round11::LoadedCodeResult;
using zody::cua::round11::verify_loaded_code_for_pid;

constexpr char kSchema[] = "zody-cua-suspended-node-probe/v1";
constexpr char kStdinPayload[] = "console.log(42)\n";
constexpr char kSpawnFlags[] = "POSIX_SPAWN_START_SUSPENDED|POSIX_SPAWN_CLOEXEC_DEFAULT";
constexpr size_t kMaxCapturedOutput = 64 * 1024;
constexpr int kSuspendTimeoutMs = 3000;
constexpr int kStdinTimeoutMs = 3000;
constexpr int kOutputTimeoutMs = 5000;
constexpr int kWaitTimeoutMs = 5000;
constexpr int kReapTimeoutMs = 2000;

int remaining_ms(Clock::time_point deadline) {
  const auto remaining = std::chrono::duration_cast<std::chrono::milliseconds>(
                             deadline - Clock::now())
                             .count();
  if (remaining <= 0) return 0;
  if (remaining > INT_MAX) return INT_MAX;
  return static_cast<int>(remaining);
}

std::string errno_text(int value) { return std::strerror(value); }

std::string ns_to_std(NSString* value) {
  if (value == nil) return "";
  const char* utf8 = [value UTF8String];
  return utf8 == nullptr ? "" : std::string(utf8);
}

NSString* std_to_ns(const std::string& value) {
  NSString* text = [NSString stringWithUTF8String:value.c_str()];
  return text == nil ? @"" : text;
}

id nullable_string(bool present, const std::string& value) {
  return present ? static_cast<id>(std_to_ns(value)) : static_cast<id>([NSNull null]);
}

std::string iso8601_now() {
  NSISO8601DateFormatter* formatter = [[NSISO8601DateFormatter alloc] init];
  formatter.formatOptions = NSISO8601DateFormatWithInternetDateTime |
                            NSISO8601DateFormatWithFractionalSeconds;
  return ns_to_std([formatter stringFromDate:[NSDate date]]);
}

std::string hex_encode(const unsigned char* bytes, size_t length) {
  static const char* hex = "0123456789abcdef";
  std::string result;
  result.reserve(length * 2);
  for (size_t index = 0; index < length; ++index) {
    result.push_back(hex[(bytes[index] >> 4) & 0x0f]);
    result.push_back(hex[bytes[index] & 0x0f]);
  }
  return result;
}

bool is_hex(const std::string& value, size_t expected_length) {
  if (value.size() != expected_length) return false;
  for (char character : value) {
    if (std::isxdigit(static_cast<unsigned char>(character)) == 0) return false;
  }
  return true;
}

class ScopedFd {
 public:
  ScopedFd() = default;
  explicit ScopedFd(int fd) : fd_(fd) {}
  ~ScopedFd() { reset(); }
  ScopedFd(const ScopedFd&) = delete;
  ScopedFd& operator=(const ScopedFd&) = delete;
  ScopedFd(ScopedFd&& other) noexcept : fd_(other.release()) {}
  ScopedFd& operator=(ScopedFd&& other) noexcept {
    if (this != &other) reset(other.release());
    return *this;
  }

  int get() const { return fd_; }
  bool valid() const { return fd_ >= 0; }
  int release() {
    const int released = fd_;
    fd_ = -1;
    return released;
  }
  void reset(int fd = -1) {
    if (fd_ >= 0) close(fd_);
    fd_ = fd;
  }

 private:
  int fd_ = -1;
};

struct PinSet {
  std::string identifier;
  std::string leaf_sha256;
  std::string designated_requirement;
  std::string cdhash_hex;
};

struct ProcState {
  bool available = false;
  uint32_t status = 0;
  uint64_t start_sec = 0;
  uint64_t start_usec = 0;
  std::string error;
};

struct SuspendedEvidence {
  bool observed = false;
  bool detected = false;
  uint32_t status = 0;
  std::string status_name;
  uint64_t start_sec = 0;
  uint64_t start_usec = 0;
  std::string last_error;
};

struct EntitlementsEvidence {
  bool queried = false;
  bool present = false;
  bool empty = true;
  bool json_available = false;
  std::string json;
  std::string error;
};

struct WaitEvidence {
  bool reaped = false;
  bool timed_out = false;
  bool exited = false;
  bool signaled = false;
  int exit_code = -1;
  int signal = 0;
  int status = 0;
  int error = 0;
  std::string error_text;
};

struct CleanupEvidence {
  bool attempted = false;
  bool kill_sent = false;
  bool reaped = false;
  bool timed_out = false;
  std::string error;
  WaitEvidence wait;
};

struct ChildIo {
  std::string out;
  std::string err;
  bool out_eof = false;
  bool err_eof = false;
  bool timed_out = false;
  std::string error;
};

struct SpawnResult {
  bool ok = false;
  pid_t pid = -1;
  ScopedFd stdin_write;
  ScopedFd stdout_read;
  ScopedFd stderr_read;
  std::string error;
  CleanupEvidence cleanup;
};

struct ProbeReport {
  std::string schema = kSchema;
  std::string started_at;
  std::string target_path;
  std::string pins_path;
  std::string target_sha256;
  bool target_sha256_available = false;
  std::string target_sha256_error;
  PinSet pins;
  bool pins_loaded = false;
  std::string pins_error;
  pid_t pid = -1;
  bool spawned = false;
  std::string spawn_error;
  SuspendedEvidence suspended;
  ProcState pre_resume;
  LoadedCodeResult loaded;
  bool loaded_available = false;
  EntitlementsEvidence entitlements;
  bool verification_accepted = false;
  std::string verification_reason;
  bool resumed = false;
  int resume_errno = 0;
  std::string resume_error;
  bool stdin_written = false;
  size_t stdin_bytes = 0;
  std::string stdin_error;
  ChildIo child_io;
  WaitEvidence wait;
  bool child_reaped = false;
  CleanupEvidence cleanup;
  std::string stage = "init";
  std::string error;
  bool ok = false;
  int exit_code = 3;
  long long duration_ms = 0;
};

bool load_pins(const std::string& path, PinSet& pins, std::string& error) {
  NSString* file_path = std_to_ns(path);
  NSError* ns_error = nil;
  NSData* data = [NSData dataWithContentsOfFile:file_path options:0 error:&ns_error];
  if (data == nil) {
    error = "cannot-read-pins: " + ns_to_std([ns_error localizedDescription]);
    return false;
  }
  id root = [NSJSONSerialization JSONObjectWithData:data options:0 error:&ns_error];
  if (root == nil || ![root isKindOfClass:[NSDictionary class]]) {
    error = "pins-json-not-object: " + ns_to_std([ns_error localizedDescription]);
    return false;
  }
  NSDictionary* dictionary = static_cast<NSDictionary*>(root);
  auto read_string = [&](NSString* key, std::string& output) -> bool {
    id value = [dictionary objectForKey:key];
    if (![value isKindOfClass:[NSString class]]) {
      error = "pins-missing-string: " + ns_to_std(key);
      return false;
    }
    output = ns_to_std(static_cast<NSString*>(value));
    if (output.empty()) {
      error = "pins-empty-string: " + ns_to_std(key);
      return false;
    }
    return true;
  };
  if (!read_string(@"nodeIdentifier", pins.identifier)) return false;
  if (!read_string(@"nodeLeafSha256", pins.leaf_sha256)) return false;
  if (!read_string(@"nodeDesignatedRequirement", pins.designated_requirement)) return false;
  if (!read_string(@"nodeCdhash", pins.cdhash_hex)) return false;
  if (!is_hex(pins.leaf_sha256, 64)) {
    error = "pins-nodeLeafSha256-not-64-hex";
    return false;
  }
  if (!is_hex(pins.cdhash_hex, 40)) {
    error = "pins-nodeCdhash-not-40-hex";
    return false;
  }
  return true;
}

bool sha256_file(const std::string& path, std::string& hex, std::string& error) {
  ScopedFd file(open(path.c_str(), O_RDONLY | O_CLOEXEC));
  if (!file.valid()) {
    error = "open-target: " + errno_text(errno);
    return false;
  }
  CC_SHA256_CTX context;
  CC_SHA256_Init(&context);
  std::array<unsigned char, 1024 * 1024> buffer;
  for (;;) {
    const ssize_t count = read(file.get(), buffer.data(), buffer.size());
    if (count > 0) {
      CC_SHA256_Update(&context, buffer.data(), static_cast<CC_LONG>(count));
      continue;
    }
    if (count == 0) break;
    if (errno == EINTR) continue;
    error = "read-target: " + errno_text(errno);
    return false;
  }
  unsigned char digest[CC_SHA256_DIGEST_LENGTH];
  CC_SHA256_Final(digest, &context);
  hex = hex_encode(digest, sizeof(digest));
  return true;
}

std::string proc_status_name(uint32_t status) {
  switch (status) {
    case SIDL:
      return "SIDL";
    case SRUN:
      return "SRUN";
    case SSLEEP:
      return "SSLEEP";
    case SSTOP:
      return "SSTOP";
    case SZOMB:
      return "SZOMB";
    default:
      return "UNKNOWN";
  }
}

ProcState query_proc_state(pid_t pid) {
  ProcState state;
  proc_bsdinfo info {};
  errno = 0;
  const int bytes = proc_pidinfo(pid, PROC_PIDTBSDINFO, 0, &info, sizeof(info));
  if (bytes == static_cast<int>(sizeof(info)) &&
      info.pbi_pid == static_cast<uint32_t>(pid)) {
    state.available = true;
    state.status = info.pbi_status;
    state.start_sec = info.pbi_start_tvsec;
    state.start_usec = info.pbi_start_tvusec;
    return state;
  }
  const int failure = errno;
  if (bytes == static_cast<int>(sizeof(info))) {
    state.error = "proc-pid-mismatch";
  } else if (failure == ESRCH) {
    state.error = "esrch";
  } else if (failure == 0) {
    state.error = "proc_pidinfo-short-read";
  } else {
    state.error = "proc_pidinfo: " + errno_text(failure);
  }
  return state;
}

bool wait_for_suspended(pid_t pid, int timeout_ms, SuspendedEvidence& evidence,
                        std::string& error) {
  const auto deadline = Clock::now() + std::chrono::milliseconds(timeout_ms);
  for (;;) {
    const ProcState state = query_proc_state(pid);
    if (state.available) {
      evidence.observed = true;
      evidence.status = state.status;
      evidence.status_name = proc_status_name(state.status);
      evidence.start_sec = state.start_sec;
      evidence.start_usec = state.start_usec;
      evidence.last_error.clear();
      if (state.status == SSTOP) {
        evidence.detected = true;
        return true;
      }
      if (state.status == SZOMB) {
        error = "child-exited-before-suspend";
        return false;
      }
    } else {
      evidence.last_error = state.error;
      if (state.error == "esrch") {
        error = "child-exited-before-suspend";
        return false;
      }
    }
    if (remaining_ms(deadline) <= 0) break;
    usleep(10'000);
  }
  error = "suspend-detection-timeout";
  return false;
}

bool same_suspended_process(pid_t pid, const SuspendedEvidence& evidence,
                            ProcState& state) {
  state = query_proc_state(pid);
  return state.available && state.status == SSTOP &&
         state.start_sec == evidence.start_sec &&
         state.start_usec == evidence.start_usec;
}

std::string canonical_json(CFTypeRef value) {
  NSError* error = nil;
  NSData* data = [NSJSONSerialization dataWithJSONObject:(__bridge id)value
                                                 options:NSJSONWritingSortedKeys
                                                   error:&error];
  if (data == nil || error != nil) return "";
  NSString* text = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
  return ns_to_std(text);
}

EntitlementsEvidence query_entitlements(pid_t pid) {
  EntitlementsEvidence evidence;
  int pid_value = static_cast<int>(pid);
  CFNumberRef pid_number = CFNumberCreate(nullptr, kCFNumberIntType, &pid_value);
  if (pid_number == nullptr) {
    evidence.error = "entitlements-pid-allocation-failed";
    return evidence;
  }
  const void* keys[] = {kSecGuestAttributePid};
  const void* values[] = {pid_number};
  CFDictionaryRef attributes = CFDictionaryCreate(
      nullptr, keys, values, 1, &kCFTypeDictionaryKeyCallBacks,
      &kCFTypeDictionaryValueCallBacks);
  CFRelease(pid_number);
  if (attributes == nullptr) {
    evidence.error = "entitlements-attributes-allocation-failed";
    return evidence;
  }
  SecCodeRef code = nullptr;
  OSStatus status = SecCodeCopyGuestWithAttributes(
      nullptr, attributes, kSecCSDefaultFlags, &code);
  CFRelease(attributes);
  if (status != errSecSuccess || code == nullptr) {
    evidence.error = "entitlements-loaded-code-unavailable";
    if (code != nullptr) CFRelease(code);
    return evidence;
  }
  CFDictionaryRef information = nullptr;
  status = SecCodeCopySigningInformation(
      code, kSecCSSigningInformation | kSecCSRequirementInformation, &information);
  if (status != errSecSuccess || information == nullptr) {
    evidence.error = "entitlements-signing-information-unavailable";
    CFRelease(code);
    if (information != nullptr) CFRelease(information);
    return evidence;
  }
  CFTypeRef value = CFDictionaryGetValue(information, kSecCodeInfoEntitlementsDict);
  evidence.queried = true;
  if (value == nullptr) {
    evidence.present = false;
    evidence.empty = true;
  } else if (CFGetTypeID(value) == CFDictionaryGetTypeID()) {
    evidence.present = true;
    evidence.empty = CFDictionaryGetCount(static_cast<CFDictionaryRef>(value)) == 0;
    evidence.json = canonical_json(value);
    if (evidence.json.empty()) {
      evidence.error = "entitlements-json-unavailable";
    } else {
      evidence.json_available = true;
    }
  } else {
    evidence.error = "entitlements-not-a-dictionary";
  }
  CFRelease(information);
  CFRelease(code);
  return evidence;
}

WaitEvidence wait_child_bounded(pid_t pid, int timeout_ms) {
  WaitEvidence evidence;
  const auto deadline = Clock::now() + std::chrono::milliseconds(timeout_ms);
  for (;;) {
    int status = 0;
    errno = 0;
    const pid_t result = waitpid(pid, &status, WNOHANG);
    if (result == pid) {
      evidence.status = status;
      if (WIFEXITED(status)) {
        evidence.reaped = true;
        evidence.exited = true;
        evidence.exit_code = WEXITSTATUS(status);
      } else if (WIFSIGNALED(status)) {
        evidence.reaped = true;
        evidence.signaled = true;
        evidence.signal = WTERMSIG(status);
      } else if (WIFSTOPPED(status)) {
        evidence.error_text = "unexpected-stopped-status";
      } else {
        evidence.error_text = "unrecognized-wait-status";
      }
      return evidence;
    }
    if (result == 0) {
      if (remaining_ms(deadline) <= 0) {
        evidence.timed_out = true;
        evidence.error_text = "wait-timeout";
        return evidence;
      }
      usleep(10'000);
      continue;
    }
    if (errno == EINTR) continue;
    evidence.error = errno;
    evidence.error_text = "waitpid: " + errno_text(errno);
    return evidence;
  }
}

CleanupEvidence terminate_and_reap(pid_t pid) {
  CleanupEvidence cleanup;
  if (pid <= 0) {
    cleanup.error = "no-child";
    return cleanup;
  }
  cleanup.attempted = true;
  for (int attempt = 0; attempt < 3 && !cleanup.reaped; ++attempt) {
    errno = 0;
    const int result = kill(pid, SIGKILL);
    if (result == 0) {
      cleanup.kill_sent = true;
    } else if (errno != ESRCH && cleanup.error.empty()) {
      cleanup.error = "kill: " + errno_text(errno);
    }
    cleanup.wait = wait_child_bounded(pid, kReapTimeoutMs);
    cleanup.reaped = cleanup.wait.reaped;
    cleanup.timed_out = cleanup.wait.timed_out;
    if (cleanup.reaped) break;
    if (cleanup.wait.error == ECHILD) break;
  }
  return cleanup;
}

SpawnResult spawn_suspended(const std::string& target) {
  SpawnResult result;
  int stdin_pipe[2] = {-1, -1};
  int stdout_pipe[2] = {-1, -1};
  int stderr_pipe[2] = {-1, -1};
  if (pipe(stdin_pipe) != 0 || pipe(stdout_pipe) != 0 || pipe(stderr_pipe) != 0) {
    const int failure = errno;
    for (int fd : stdin_pipe) if (fd >= 0) close(fd);
    for (int fd : stdout_pipe) if (fd >= 0) close(fd);
    for (int fd : stderr_pipe) if (fd >= 0) close(fd);
    result.error = "pipe: " + errno_text(failure);
    return result;
  }

  ScopedFd stdin_read(stdin_pipe[0]);
  ScopedFd stdin_write(stdin_pipe[1]);
  ScopedFd stdout_read(stdout_pipe[0]);
  ScopedFd stdout_write(stdout_pipe[1]);
  ScopedFd stderr_read(stderr_pipe[0]);
  ScopedFd stderr_write(stderr_pipe[1]);

  int child_stdin = fcntl(stdin_read.get(), F_DUPFD_CLOEXEC, 10);
  int child_stdout = fcntl(stdout_write.get(), F_DUPFD_CLOEXEC, 10);
  int child_stderr = fcntl(stderr_write.get(), F_DUPFD_CLOEXEC, 10);
  if (child_stdin < 0 || child_stdout < 0 || child_stderr < 0) {
    const int failure = errno;
    if (child_stdin >= 0) close(child_stdin);
    if (child_stdout >= 0) close(child_stdout);
    if (child_stderr >= 0) close(child_stderr);
    result.error = "fcntl-child-fd: " + errno_text(failure);
    return result;
  }
  stdin_read.reset();
  stdout_write.reset();
  stderr_write.reset();

  posix_spawn_file_actions_t actions {};
  posix_spawnattr_t attributes {};
  bool actions_initialized = false;
  bool attributes_initialized = false;
  int status = posix_spawn_file_actions_init(&actions);
  if (status == 0) {
    actions_initialized = true;
    status = posix_spawnattr_init(&attributes);
    if (status == 0) attributes_initialized = true;
  }
  if (status == 0)
    status = posix_spawn_file_actions_adddup2(&actions, child_stdin, STDIN_FILENO);
  if (status == 0)
    status = posix_spawn_file_actions_adddup2(&actions, child_stdout, STDOUT_FILENO);
  if (status == 0)
    status = posix_spawn_file_actions_adddup2(&actions, child_stderr, STDERR_FILENO);
  if (status == 0) status = posix_spawn_file_actions_addclose(&actions, child_stdin);
  if (status == 0) status = posix_spawn_file_actions_addclose(&actions, child_stdout);
  if (status == 0) status = posix_spawn_file_actions_addclose(&actions, child_stderr);
  if (status == 0) {
    status = posix_spawnattr_setflags(
        &attributes, POSIX_SPAWN_START_SUSPENDED | POSIX_SPAWN_CLOEXEC_DEFAULT);
  }
  if (status != 0) {
    if (actions_initialized) posix_spawn_file_actions_destroy(&actions);
    if (attributes_initialized) posix_spawnattr_destroy(&attributes);
    close(child_stdin);
    close(child_stdout);
    close(child_stderr);
    result.error = "posix_spawn-setup: " + errno_text(status);
    return result;
  }

  char* argv[] = {
      const_cast<char*>(target.c_str()),
      const_cast<char*>("--jitless"),
      const_cast<char*>("--no-warnings"),
      const_cast<char*>("--input-type=module"),
      nullptr,
  };
  char* envp[] = {
      const_cast<char*>("PATH=/usr/bin:/bin"),
      const_cast<char*>("LANG=C"),
      const_cast<char*>("LC_ALL=C"),
      nullptr,
  };
  pid_t pid = -1;
  const int spawn_status =
      posix_spawn(&pid, target.c_str(), &actions, &attributes, argv, envp);
  posix_spawn_file_actions_destroy(&actions);
  posix_spawnattr_destroy(&attributes);
  close(child_stdin);
  close(child_stdout);
  close(child_stderr);
  if (spawn_status != 0) {
    result.error = "posix_spawn: " + errno_text(spawn_status);
    return result;
  }

  if (fcntl(stdin_write.get(), F_SETFL, O_NONBLOCK) != 0 ||
      fcntl(stdout_read.get(), F_SETFL, O_NONBLOCK) != 0 ||
      fcntl(stderr_read.get(), F_SETFL, O_NONBLOCK) != 0) {
    const int failure = errno;
    result.pid = pid;
    result.cleanup = terminate_and_reap(pid);
    result.error = "fcntl-parent-nonblocking: " + errno_text(failure);
    return result;
  }

  result.ok = true;
  result.pid = pid;
  result.stdin_write = std::move(stdin_write);
  result.stdout_read = std::move(stdout_read);
  result.stderr_read = std::move(stderr_read);
  return result;
}

bool write_stdin_bounded(ScopedFd& fd, size_t& bytes_written, std::string& error) {
  ScopedFd pipe(std::move(fd));
  const size_t length = sizeof(kStdinPayload) - 1;
  bytes_written = 0;
  const auto deadline = Clock::now() + std::chrono::milliseconds(kStdinTimeoutMs);
  while (bytes_written < length) {
    const int wait_ms = remaining_ms(deadline);
    if (wait_ms <= 0) {
      error = "stdin-write-timeout";
      return false;
    }
    pollfd descriptor {};
    descriptor.fd = pipe.get();
    descriptor.events = POLLOUT;
    const int ready = poll(&descriptor, 1, wait_ms);
    if (ready < 0) {
      if (errno == EINTR) continue;
      error = "stdin-poll: " + errno_text(errno);
      return false;
    }
    if (ready == 0) {
      error = "stdin-write-timeout";
      return false;
    }
    if ((descriptor.revents & (POLLERR | POLLHUP | POLLNVAL)) != 0) {
      error = "stdin-pipe-closed";
      return false;
    }
    const ssize_t count =
        write(pipe.get(), kStdinPayload + bytes_written, length - bytes_written);
    if (count > 0) {
      bytes_written += static_cast<size_t>(count);
      continue;
    }
    if (count == 0) {
      error = "stdin-write-zero";
      return false;
    }
    if (errno == EINTR || errno == EAGAIN || errno == EWOULDBLOCK) continue;
    error = "stdin-write: " + errno_text(errno);
    return false;
  }
  pipe.reset();
  return true;
}

bool drain_fd(ScopedFd& fd, std::string& sink, std::string& error) {
  while (fd.valid()) {
    char buffer[4096];
    const ssize_t count = read(fd.get(), buffer, sizeof(buffer));
    if (count > 0) {
      if (sink.size() + static_cast<size_t>(count) > kMaxCapturedOutput) {
        error = "child-output-exceeds-limit";
        return false;
      }
      sink.append(buffer, static_cast<size_t>(count));
      continue;
    }
    if (count == 0) {
      fd.reset();
      return true;
    }
    if (errno == EINTR) continue;
    if (errno == EAGAIN || errno == EWOULDBLOCK) return true;
    error = "child-read: " + errno_text(errno);
    return false;
  }
  return true;
}

bool read_pipes_bounded(ScopedFd& stdout_read, ScopedFd& stderr_read,
                        ChildIo& evidence, std::string& error) {
  ScopedFd out(std::move(stdout_read));
  ScopedFd err(std::move(stderr_read));
  const auto deadline = Clock::now() + std::chrono::milliseconds(kOutputTimeoutMs);
  while (out.valid() || err.valid()) {
    const int wait_ms = remaining_ms(deadline);
    if (wait_ms <= 0) {
      evidence.timed_out = true;
      error = "child-output-timeout";
      return false;
    }
    pollfd descriptors[2] = {
        {out.valid() ? out.get() : -1, static_cast<short>(POLLIN | POLLHUP), 0},
        {err.valid() ? err.get() : -1, static_cast<short>(POLLIN | POLLHUP), 0},
    };
    const int ready = poll(descriptors, 2, std::min(wait_ms, 50));
    if (ready < 0) {
      if (errno == EINTR) continue;
      error = "child-poll: " + errno_text(errno);
      return false;
    }
    if (ready == 0) continue;
    if (descriptors[0].fd >= 0 &&
        (descriptors[0].revents & (POLLERR | POLLNVAL)) != 0) {
      error = "stdout-poll-error";
      return false;
    }
    if (descriptors[1].fd >= 0 &&
        (descriptors[1].revents & (POLLERR | POLLNVAL)) != 0) {
      error = "stderr-poll-error";
      return false;
    }
    if (descriptors[0].fd >= 0 &&
        (descriptors[0].revents & (POLLIN | POLLHUP)) != 0 &&
        !drain_fd(out, evidence.out, error)) {
      return false;
    }
    if (descriptors[1].fd >= 0 &&
        (descriptors[1].revents & (POLLIN | POLLHUP)) != 0 &&
        !drain_fd(err, evidence.err, error)) {
      return false;
    }
  }
  evidence.out_eof = true;
  evidence.err_eof = true;
  return true;
}

NSDictionary* loaded_code_json(const LoadedCodeResult& loaded, bool available) {
  return @{
    @"available" : @(available),
    @"ok" : @(loaded.ok),
    @"reason" : std_to_ns(loaded.reason),
    @"guestCreated" : @(loaded.guest_created),
    @"codeValid" : @(loaded.code_valid),
    @"requirementMatched" : @(loaded.requirement_matched),
    @"adhoc" : @(loaded.adhoc),
    @"certificatePresent" : @(loaded.certificate_present),
    @"hardenedRuntime" : @(loaded.hardened_runtime),
    @"leafMatched" : @(loaded.leaf_matched),
    @"identifierMatched" : @(loaded.identifier_matched),
    @"entitlementsEmpty" : @(loaded.entitlements_empty),
    @"cdhashMatched" : @(loaded.cdhash_matched),
    @"cdhashHex" : std_to_ns(loaded.cdhash_hex),
    @"identifier" : std_to_ns(loaded.identifier),
    @"leafSha256" : std_to_ns(loaded.leaf_sha256),
    @"designatedRequirement" : std_to_ns(loaded.designated_requirement),
    @"flags" : @(loaded.flags),
  };
}

NSDictionary* wait_json(const WaitEvidence& wait) {
  return @{
    @"reaped" : @(wait.reaped),
    @"timedOut" : @(wait.timed_out),
    @"exited" : @(wait.exited),
    @"signaled" : @(wait.signaled),
    @"exitCode" : @(wait.exit_code),
    @"signal" : @(wait.signal),
    @"status" : @(wait.status),
    @"error" : @(wait.error),
    @"errorText" : std_to_ns(wait.error_text),
  };
}

int emit_report(ProbeReport& report, Clock::time_point started) {
  report.duration_ms = std::chrono::duration_cast<std::chrono::milliseconds>(
                           Clock::now() - started)
                           .count();
  NSMutableDictionary* root = [NSMutableDictionary dictionary];
  root[@"schema"] = std_to_ns(report.schema);
  root[@"ok"] = @(report.ok);
  root[@"exitCode"] = @(report.exit_code);
  root[@"stage"] = std_to_ns(report.stage);
  root[@"error"] = std_to_ns(report.error);
  root[@"startedAt"] = std_to_ns(report.started_at);
  root[@"finishedAt"] = std_to_ns(iso8601_now());
  root[@"durationMs"] = @(report.duration_ms);
  root[@"target"] = @{
    @"path" : std_to_ns(report.target_path),
    @"sha256" : nullable_string(report.target_sha256_available, report.target_sha256),
    @"sha256Error" : std_to_ns(report.target_sha256_error),
  };
  root[@"pins"] = @{
    @"path" : std_to_ns(report.pins_path),
    @"loaded" : @(report.pins_loaded),
    @"error" : std_to_ns(report.pins_error),
    @"nodeIdentifier" : std_to_ns(report.pins.identifier),
    @"nodeLeafSha256" : std_to_ns(report.pins.leaf_sha256),
    @"nodeDesignatedRequirement" : std_to_ns(report.pins.designated_requirement),
    @"nodeCdhash" : std_to_ns(report.pins.cdhash_hex),
  };
  root[@"spawn"] = @{
    @"pid" : @(static_cast<int>(report.pid)),
    @"spawned" : @(report.spawned),
    @"flags" : std_to_ns(kSpawnFlags),
    @"error" : std_to_ns(report.spawn_error),
  };
  root[@"suspended"] = @{
    @"observed" : @(report.suspended.observed),
    @"detected" : @(report.suspended.detected),
    @"statusRaw" : @(report.suspended.status),
    @"statusName" : std_to_ns(report.suspended.status_name),
    @"startSec" : @(static_cast<unsigned long long>(report.suspended.start_sec)),
    @"startUsec" : @(static_cast<unsigned long long>(report.suspended.start_usec)),
    @"lastError" : std_to_ns(report.suspended.last_error),
  };
  root[@"preResume"] = @{
    @"available" : @(report.pre_resume.available),
    @"statusRaw" : @(report.pre_resume.status),
    @"statusName" : std_to_ns(proc_status_name(report.pre_resume.status)),
    @"startSec" : @(static_cast<unsigned long long>(report.pre_resume.start_sec)),
    @"startUsec" : @(static_cast<unsigned long long>(report.pre_resume.start_usec)),
    @"error" : std_to_ns(report.pre_resume.error),
  };
  root[@"verification"] = @{
    @"reusedFunction" : @"zody::cua::round11::verify_loaded_code_for_pid",
    @"loadedCode" : loaded_code_json(report.loaded, report.loaded_available),
    @"entitlements" : @{
      @"queried" : @(report.entitlements.queried),
      @"present" : @(report.entitlements.present),
      @"empty" : @(report.entitlements.empty),
      @"jsonAvailable" : @(report.entitlements.json_available),
      @"json" : nullable_string(report.entitlements.json_available, report.entitlements.json),
      @"error" : std_to_ns(report.entitlements.error),
    },
    @"accepted" : @(report.verification_accepted),
    @"reason" : std_to_ns(report.verification_reason),
  };
  root[@"resume"] = @{
    @"sigcontSent" : @(report.resumed),
    @"errno" : @(report.resume_errno),
    @"error" : std_to_ns(report.resume_error),
  };
  root[@"stdin"] = @{
    @"sent" : @(report.stdin_written),
    @"bytes" : @(static_cast<unsigned long long>(report.stdin_bytes)),
    @"expectedBytes" : @(static_cast<unsigned long long>(sizeof(kStdinPayload) - 1)),
    @"payload" : std_to_ns(kStdinPayload),
    @"error" : std_to_ns(report.stdin_error),
  };
  root[@"child"] = @{
    @"stdout" : std_to_ns(report.child_io.out),
    @"stderr" : std_to_ns(report.child_io.err),
    @"stdoutEof" : @(report.child_io.out_eof),
    @"stderrEof" : @(report.child_io.err_eof),
    @"timedOut" : @(report.child_io.timed_out),
    @"error" : std_to_ns(report.child_io.error),
    @"reaped" : @(report.child_reaped),
    @"wait" : wait_json(report.wait),
  };
  root[@"failureCleanup"] = @{
    @"attempted" : @(report.cleanup.attempted),
    @"killSent" : @(report.cleanup.kill_sent),
    @"reaped" : @(report.cleanup.reaped),
    @"timedOut" : @(report.cleanup.timed_out),
    @"error" : std_to_ns(report.cleanup.error),
    @"wait" : wait_json(report.cleanup.wait),
  };

  NSError* json_error = nil;
  NSData* data = [NSJSONSerialization dataWithJSONObject:root
                                                 options:NSJSONWritingSortedKeys
                                                   error:&json_error];
  if (data == nil) {
    const char fallback[] =
        "{\"ok\":false,\"exitCode\":5,\"stage\":\"json-serialization\","
        "\"error\":\"json-serialization-failed\"}\n";
    fwrite(fallback, 1, sizeof(fallback) - 1, stderr);
    return 5;
  }
  fwrite(data.bytes, 1, static_cast<size_t>(data.length), stdout);
  fputc('\n', stdout);
  fflush(stdout);
  return report.exit_code;
}

}  // namespace

int main(int argc, char** argv) {
  @autoreleasepool {
    signal(SIGPIPE, SIG_IGN);
    const auto started = Clock::now();
    ProbeReport report;
    report.started_at = iso8601_now();
    if (argc != 3) {
      report.stage = "usage";
      report.error = "usage: suspended-node-probe <target-executable> <identity-pins.json>";
      report.exit_code = 3;
      return emit_report(report, started);
    }
    report.target_path = argv[1];
    report.pins_path = argv[2];
    if (!sha256_file(report.target_path, report.target_sha256,
                     report.target_sha256_error)) {
      report.target_sha256_available = false;
    } else {
      report.target_sha256_available = true;
    }
    if (!load_pins(report.pins_path, report.pins, report.pins_error)) {
      report.stage = "pins";
      report.error = report.pins_error;
      report.exit_code = 3;
      return emit_report(report, started);
    }
    report.pins_loaded = true;

    SpawnResult spawn = spawn_suspended(report.target_path);
    report.pid = spawn.pid;
    report.spawned = spawn.pid > 0;
    report.spawn_error = spawn.error;
    report.cleanup = spawn.cleanup;
    if (!spawn.ok) {
      report.stage = "spawn";
      report.error = spawn.error;
      report.cleanup.attempted = spawn.cleanup.attempted;
      report.child_reaped = spawn.cleanup.reaped;
      report.exit_code = 3;
      return emit_report(report, started);
    }

    auto fail_with_cleanup = [&](const std::string& stage, const std::string& error,
                                 int exit_code) -> int {
      report.stage = stage;
      report.error = error;
      report.cleanup = terminate_and_reap(report.pid);
      report.child_reaped = report.cleanup.reaped;
      report.exit_code = exit_code;
      return emit_report(report, started);
    };

    std::string suspend_error;
    if (!wait_for_suspended(report.pid, kSuspendTimeoutMs, report.suspended,
                            suspend_error)) {
      return fail_with_cleanup("suspended", suspend_error, 3);
    }

    LoadedCodeExpectation expected;
    expected.identifier = report.pins.identifier;
    expected.leaf_certificate_sha256 = report.pins.leaf_sha256;
    expected.designated_requirement = report.pins.designated_requirement;
    expected.cdhash_hex = report.pins.cdhash_hex;
    expected.require_empty_entitlements = true;
    report.loaded = verify_loaded_code_for_pid(report.pid, expected);
    report.loaded_available = true;
    report.entitlements = query_entitlements(report.pid);
    report.verification_accepted =
        report.loaded.ok && report.entitlements.queried &&
        report.entitlements.error.empty() &&
        (!report.entitlements.present || report.entitlements.empty);
    if (!report.loaded.ok) {
      report.verification_reason = report.loaded.reason;
    } else if (!report.entitlements.queried) {
      report.verification_reason = "entitlements-evidence-unavailable";
    } else if (!report.entitlements.error.empty()) {
      report.verification_reason = report.entitlements.error;
    } else if (report.entitlements.present && !report.entitlements.empty) {
      report.verification_reason = "loaded-code-unexpected-entitlements";
    } else {
      report.verification_reason = "accepted";
    }
    if (!report.verification_accepted) {
      return fail_with_cleanup("verification", report.verification_reason, 2);
    }

    if (!same_suspended_process(report.pid, report.suspended, report.pre_resume)) {
      return fail_with_cleanup("pre-resume", "suspended-process-changed", 3);
    }
    errno = 0;
    if (kill(report.pid, SIGCONT) != 0) {
      report.resume_errno = errno;
      report.resume_error = "sigcont: " + errno_text(errno);
      return fail_with_cleanup("resume", report.resume_error, 4);
    }
    report.resumed = true;

    if (!write_stdin_bounded(spawn.stdin_write, report.stdin_bytes,
                             report.stdin_error)) {
      return fail_with_cleanup("stdin", report.stdin_error, 4);
    }
    report.stdin_written = true;

    if (!read_pipes_bounded(spawn.stdout_read, spawn.stderr_read,
                            report.child_io, report.child_io.error)) {
      return fail_with_cleanup("child-io", report.child_io.error, 4);
    }
    report.wait = wait_child_bounded(report.pid, kWaitTimeoutMs);
    report.child_reaped = report.wait.reaped;
    if (!report.wait.reaped) {
      return fail_with_cleanup("child-wait", report.wait.error_text, 4);
    }

    const bool output_matches = report.child_io.out == "42\n";
    const bool stderr_empty = report.child_io.err.empty();
    report.ok = report.verification_accepted && report.resumed &&
                report.stdin_written && report.child_io.out_eof &&
                report.child_io.err_eof && !report.child_io.timed_out &&
                report.wait.exited && report.wait.exit_code == 0 &&
                output_matches && stderr_empty;
    if (!report.ok) {
      report.stage = "child-result";
      report.error = output_matches ? (stderr_empty ? "child-wait-result-mismatch"
                                                    : "child-stderr-not-empty")
                                    : "child-stdout-not-42";
      report.exit_code = 4;
      return emit_report(report, started);
    }

    report.stage = "complete";
    report.exit_code = 0;
    return emit_report(report, started);
  }
}
