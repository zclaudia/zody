#!/bin/sh
set -eu

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../../.." && pwd)
DIR="$ROOT/output/cua-arm64-screenshot/suspended-node-probe"
MARKER="$DIR/negative-marker-fired"

rm -f "$MARKER"
set +e
"$DIR/suspended-node-probe" \
  "$DIR/negative-marker" \
  "$ROOT/output/cua-helper-round11/controller-signed/identity-pins.json" \
  > "$DIR/negative-run.json"
STATUS=$?
set -e

test "$STATUS" -ne 0
test ! -e "$MARKER"
printf 'negative probe rejected as expected (exit %s), marker absent\n' "$STATUS"
