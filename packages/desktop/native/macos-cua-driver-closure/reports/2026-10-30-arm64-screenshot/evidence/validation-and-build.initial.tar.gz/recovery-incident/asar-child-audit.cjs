const cp = require("node:child_process");
const fs = require("node:fs");
const moduleApi = require("node:module");
const original = cp.spawnSync;
cp.spawnSync = function(command, args, options) {
  const started = Date.now();
  const result = original.apply(this, arguments);
  if (Array.isArray(args) && args.some(arg => typeof arg === "string" && arg.endsWith("/asar.js"))) {
    fs.appendFileSync("/Users/zhvala/SourceCode/zody/output/cua-arm64-screenshot/recovery-incident/asar-child-status.ndjson", JSON.stringify({time: new Date().toISOString(), command, args, elapsedMs: Date.now()-started, status: result.status, signal: result.signal, error: result.error?.code})+"\n");
  }
  return result;
};
moduleApi.syncBuiltinESMExports();
