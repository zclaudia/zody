import type {
  CuaSubmissionProducerPort,
  CuaSubmissionProjection,
  CuaSubmissionRef,
  CuaSubmissionTurnInvalidationReason,
  CuaSubmissionTurnScope,
} from "@zcode/contracts";
import type { CuaLiveSubmissionRegistrar } from "../cua/cua-submission-coordinator.js";
import { sameIdentity } from "../cua/cua-submission-helpers.js";
import { RuntimeCuaSubmissionTurnScope } from "../cua/cua-submission-turn-scope.js";
import type { AgentRuntimeInternal } from "../internal.js";
import type { ActiveForegroundExecutionState, ActiveTurnSteeringState } from "../types.js";

const UNKNOWN_CUA_SUBMISSION_PROJECTION: CuaSubmissionProjection = Object.freeze({
  status: "unknown",
  nativeFence: "unknown",
  mobileDelivery: "unknown",
});

/** 可信 runtime 边界读取；没有 coordinator 时保持 unknown，不创建任何候选。 */
export function getCuaSubmissionProjection(this: AgentRuntimeInternal): CuaSubmissionProjection {
  return this.cuaSubmissionCoordinator?.currentProjection() ?? UNKNOWN_CUA_SUBMISSION_PROJECTION;
}

export function getCuaSubmissionRegistrar(
  this: AgentRuntimeInternal,
): CuaLiveSubmissionRegistrar | undefined {
  return this.cuaSubmissionCoordinator?.registrar;
}

export function getCuaSubmissionProducerPort(
  this: AgentRuntimeInternal,
): CuaSubmissionProducerPort | undefined {
  return this.cuaSubmissionCoordinator?.producerPort();
}

export function getCurrentCuaSubmissionRef(
  this: AgentRuntimeInternal,
): CuaSubmissionRef | undefined {
  return this.cuaSubmissionCoordinator?.currentRef();
}

/**
 * 生产 runtime 的同一 owner turn scope。仅真实 regular activeTurn + 未取消 foreground
 * execution + 当前 candidate 时签发；身份全部由 runtime 捕获，调用方不能传入或覆盖。
 */
export function createCuaSubmissionTurnScope(
  this: AgentRuntimeInternal,
): CuaSubmissionTurnScope | undefined {
  const coordinator = this.cuaSubmissionCoordinator;
  if (!coordinator || this.config.parentSessionId !== undefined || this.shuttingDown) {
    return undefined;
  }
  const activeTurn = this.activeTurn;
  if (!activeTurn || activeTurn.kind !== "regular") return undefined;
  const foreground = this.activeForegroundExecution;
  if (!foreground || foreground.controller.signal.aborted) return undefined;
  const candidate = coordinator.currentProjection();
  if (candidate.status !== "candidate") return undefined;

  const scopes = (this.cuaSubmissionTurnScopesByTurn ??= new WeakMap());
  const existing = scopes.get(activeTurn);
  if (existing) {
    // 单一 turn 至多一个 handle；已关闭的 handle 不能借重复调用复活旧 turn。
    return existing.invalidated ? undefined : existing;
  }

  const scope = new RuntimeCuaSubmissionTurnScope({
    ref: candidate.ref,
    traceId: activeTurn.traceContext.traceId,
    runId: foreground.foregroundExecutionId,
    turnId: activeTurn.turnId,
    producerPort: coordinator.producerPort(),
    bindTurn: (request) => coordinator.bindTurn(request),
    endTurn: (request) => coordinator.endTurn(request),
    isBindingCurrent: () =>
      this.activeTurn === activeTurn &&
      this.activeForegroundExecution === foreground &&
      !foreground.controller.signal.aborted &&
      coordinator.isCurrentCandidateRef(candidate.ref),
  });
  scopes.set(activeTurn, scope);
  this.cuaSubmissionTurnScope = scope;

  const unsubscribe = coordinator.subscribeRevocation((projection) => {
    // 只有同一 lineage 的 owner 撤销才失效本 scope；别的会话/lineage 不得误伤。
    if (sameIdentity(projection.ref, candidate.ref)) scope.invalidate("owner-revoked");
  });
  // foreground 的 parent AbortSignal 可能先于 held model/turn 生命周期结束；必须直接订阅
  // 真实 controller signal，abort 时同步失效，不能等 finishForegroundExecution 兜底。
  const onForegroundAbort = (): void => scope.invalidate("scope-closed");
  foreground.controller.signal.addEventListener("abort", onForegroundAbort, { once: true });
  scope.onInvalidated(() => {
    foreground.controller.signal.removeEventListener("abort", onForegroundAbort);
    unsubscribe();
    if (this.cuaSubmissionTurnScope === scope) this.cuaSubmissionTurnScope = undefined;
  });
  return scope;
}

/** 真实 turn 结束时同步失效；正常结束只释放 binding，不撤销仍有效的 lineage。 */
export function invalidateCuaSubmissionTurnScopeForTurn(
  this: AgentRuntimeInternal,
  activeTurn: ActiveTurnSteeringState,
  reason: CuaSubmissionTurnInvalidationReason,
): void {
  this.cuaSubmissionTurnScopesByTurn?.get(activeTurn)?.invalidate(reason);
}

/** foreground execution 结束/取消时兜底失效；runId 对不上时不得影响其它 handle。 */
export function invalidateCuaSubmissionTurnScopeForForeground(
  this: AgentRuntimeInternal,
  state: ActiveForegroundExecutionState,
  reason: CuaSubmissionTurnInvalidationReason,
): void {
  const scope = this.cuaSubmissionTurnScope;
  if (scope?.runId !== state.foregroundExecutionId) return;
  scope.invalidate(reason);
}

/** shutdown 是不可恢复的 owner 撤销，不能走 normal close 语义。 */
export function invalidateCuaSubmissionTurnScopeOnDispose(this: AgentRuntimeInternal): void {
  this.cuaSubmissionTurnScope?.invalidate("owner-revoked");
}
