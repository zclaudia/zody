import os,sys,stat,fcntl,json,datetime,pathlib
phase,outfile,helper=sys.argv[1:]
p=f"/tmp/io.github.zclaudia.zody.cua.machine.{os.geteuid()}.lock"
a=os.lstat(p)
assert stat.S_ISREG(a.st_mode) and a.st_uid==os.geteuid() and stat.S_IMODE(a.st_mode)==0o600 and a.st_nlink==1
fd=os.open(p,os.O_RDWR|os.O_NOFOLLOW|os.O_CLOEXEC)
try:
 b=os.fstat(fd); c=os.lstat(p)
 assert (a.st_dev,a.st_ino)==(b.st_dev,b.st_ino)==(c.st_dev,c.st_ino)
 assert b.st_uid==os.geteuid() and stat.S_IMODE(b.st_mode)==0o600 and b.st_nlink==1
 try:
  fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB); result="acquired-and-immediately-unlocked"; fcntl.flock(fd,fcntl.LOCK_UN)
 except BlockingIOError: result="busy"
 try: os.kill(int(helper),0); alive=True
 except ProcessLookupError: alive=False
 v={"phase":phase,"observedAt":datetime.datetime.now(datetime.timezone.utc).isoformat(),"path":p,"device":b.st_dev,"inode":b.st_ino,"uid":b.st_uid,"mode":oct(stat.S_IMODE(b.st_mode)),"links":b.st_nlink,"result":result,"helperPid":int(helper),"helperAlive":alive}
 path=pathlib.Path(outfile); assert not path.exists(); path.write_text(json.dumps(v,indent=2));print(json.dumps(v))
finally: os.close(fd)
