# CUA normal Host narrow wiring — current worker report

## Final state

- Host narrow opt-in is compile-time only (`__ZCODE_CUA_NARROW_AGENT__`); runtime env, argv, UI, and
  `candidateNativeHostLaunch` cannot select it. The ordinary utility Host remains intact.
- The selective resolver is installed only for local, non-remote, lane `undefined`/`chat` spawns.
  It compares the actual service startup snapshot with the pinned provider digest, selection,
  network digest, workspace allowlist, launcher/manifest identity, target, and capabilities before
  using the narrow route. Any mismatch or read failure returns `null` to the ordinary Agent.
- The startup snapshot is read back from existing services once per new spawn. It emits only
  `providerRevisionSha256`, normalized `selection`, and `networkDigestSha256`; no raw provider base
  URL, key, header, proxy, or CA path is logged.
- Formal resource chain now copies the validated prepared manifest byte-for-byte to
  `Contents/Resources/cua-narrow/manifest.json`; `afterPack` and `afterSign` re-check its bytes/hash.
  No explicit manifest means the narrow slot is not assembled.
- The candidate builder rebuilds main/host/scheduler from workspace source, keeps the complete
  runtime `node_modules` and reused renderer/preload/plugin-sandbox outputs, and writes
  `build-evidence/{main,host,scheduler}.metafile.json` plus `inputs.json` with repo-relative input
  paths and SHA-256. Workspace `dist` inputs are rejected.
- Candidate identity is independent (`io.github.zclaudia.zody.cua-normal-host-candidate`,
  `Zody CUA Normal Host Candidate`, package `zody-cua-normal-host-candidate`). The four existing
  Chromium Helper bundles/executables (`Helper`, `GPU`, `Renderer`, `Plugin`) are renamed to the
  candidate parent prefix; fixed native CUA Helper/Node bytes and identities are untouched. The
  existing rename helper still defaults to the old `Electron` prefix for prior callers. Flags are
  separate: `productDefaultDisabled`, `zcodeCuaPlaceholder`, `explicitCandidateOptIn`.
- Candidate and formal Darwin packaging use one ASAR integrity owner. `Info.plist` stores SHA-256 of
  the exact raw ASAR header UTF-8 bytes from `@electron/asar.getRawHeader`; the archive full SHA-256
  is a separate field. Formal `afterPack` refreshes after the last ASAR rewrite/sourcemap cleanup and
  therefore before signing; the candidate refreshes after its final repack and before manifest
  output. Missing/malformed archives, missing/non-SHA256 plist entries, and failed readback fail
  closed. Candidate manifest fields are `appAsar.{algorithm,headerBytes,headerSha256,archiveBytes,
  archiveSha256,embeddedIntegrityUpdated}`.
- Full-shell copies request `COPYFILE_FICLONE` and retain normal-copy fallback. The outer candidate
  `assemble` function remains the only staging/create/cleanup/rename transaction owner.

## Artifact status

- The old `normal-host-candidate-smoke/Zody Preview.app` fixture was removed. Its retained
  `normal-host-candidate-manifest.json` and `host-profile.json` are diagnostics only, **not formal
  evidence** of a normal shell, signature, launch, or capture.
- No app build or smoke copy was produced in the latest turn.

## Operational artifact provenance

- This product-phase report was reproduced from the pre-repair worker report bytes
  (`sha256 16b607c31c71b2825ae2da6203c1053eaafad89c29f28fa0bd238d86ec014de6`) before this
  provenance section was added.
- `output/cua-arm64-screenshot/host-worker/host-worker-report.md` was unintentionally edited in the
  old read-only namespace during the packaging fix. It was restored with the exact inverse of that
  edit; restored bytes are `sha256 c0a77c80c6b0a45b12ee66fac8009ac42187907d922a866531a1ce299bd527a3`.
  No HEAD checkout or approximate reconstruction was used.
- `output/cua-arm64-screenshot/host-worker/normal-host-packaging-source-freeze.json` was created
  during this turn in the old namespace and moved here unchanged
  (`sha256 5197ca04ab1b376f7116e81b5f3646a342fbf09b790d99ea9cb479e71fd735e9`). No older artifact
  was moved or overwritten.
- This operational repair changed no production source, test, package metadata, or other old output.

## Readback v2 manifest path repair

- `packages/desktop/scripts/lib/normal-host-candidate-output.mjs` now maps every
  `app.identity.chromiumHelpers[].executable.path` through the manifest's existing `finalPath`
  mapper. Helper `from`/`to`, executable bytes/SHA-256, mode, and extra identity facts are preserved;
  the existing staging-path write guard remains unchanged.
- Root readback-v2 failed at that existing guard; the log is
  `output/cua-arm64-screenshot-product/independent-checks/normal-host-readback-build-v2.log`.
- Regression: `packages/desktop/test/normalHostCandidateManifest.test.ts` uses an absolute staging
  helper path, writes through `writeCandidateManifest`, and checks serialized final paths plus
  absence of the staging root. Red reproduced the guard; green is 2 targeted files / 9 tests,
  `oxlint` 0/0 and `oxfmt --check` passed. No broad tests, app build, UI, install, or old-output write
  occurred for this repair.
- Fresh scoped freeze:
  `output/cua-arm64-screenshot-product/host-worker/normal-host-manifest-path-source-freeze.json`
  (`sha256 d0596769415e92e381ed1d6a6328e1b389c66f2913172a6f252161c90580a94f`); the other ten
  files in the base packaging freeze remain byte-identical.

## Build commands

`$SHELL_APP` must be a real electron-builder normal app, for example
`packages/desktop/dist/mac-arm64/Zody Preview.app`. Do not substitute a manifest-only fixture.

```sh
export PATH=/Users/zhvala/.local/share/fnm/node-versions/v24.14.0/installation/bin:$PATH
ROOT=/Users/zhvala/SourceCode/zody
WORK="$ROOT/output/cua-arm64-screenshot/host-worker"
STAMP=$(date +%Y%m%dT%H%M%S)
NARROW="$WORK/narrow-prepared-$STAMP"
SHELL_APP="$ROOT/packages/desktop/dist/mac-arm64/Zody Preview.app"

node "$ROOT/packages/desktop/scripts/macos-cua-narrow-resources-prepare.mjs" \
  --app "/absolute/path/to/signed/Zody CUA Desktop Session.app" \
  --native-build-manifest "/absolute/path/to/desktop-session/build-manifest.json" \
  --output "$NARROW"

# Real production normal bundle; omit --skip-* unless reusing an already reviewed dist.
node "$ROOT/packages/desktop/scripts/bundle.mjs" \
  --os mac --arch arm64 \
  --cua-narrow-manifest "$NARROW/manifest.json"

grep -o 'cua-narrow-startup-snapshot:{.*}' "$HOST_LOG" | tail -1 \
  | sed 's/^cua-narrow-startup-snapshot://' > "$WORK/startup-snapshot.json"

node "$ROOT/packages/desktop/scripts/build-cua-normal-host-candidate.mjs" \
  --app-shell "$SHELL_APP" \
  --narrow-manifest "$NARROW/manifest.json" \
  --workspace-allowlist "/absolute/experimental/workspace" \
  --startup-snapshot "$WORK/startup-snapshot.json" \
  --output "$WORK/normal-host-candidate-$STAMP"
```

The normal bundle command above refreshes `Info.plist` ASAR header integrity in `afterPack`. The
candidate command then rebuilds and repacks from workspace source. Check
`normal-host-candidate-manifest.json` for `buildEvidence.inputsSha256`, the copied narrow manifest
SHA-256, `app.identity.chromiumHelpers`, and the separate `appAsar.headerSha256` /
`appAsar.archiveSha256`. The builder stdout also reports both app.asar digests. Use `--replace` only
for a newly created output directory owned by this run.

## Verification

- Latest packaging fix: 6 targeted vitest files passed, 30 tests. This covers raw-header versus
  archive hashing, stale-hash refresh, malformed/missing fail-closed behavior, candidate manifest
  fields, formal hook ordering, both Helper rename prefixes, all four variants, framework symlinks,
  and unchanged fixed native helper bytes.
- Narrow resource manifest node tests: 17 passed.
- Targeted `oxlint` on touched scripts/tests: 0 warnings, 0 errors; `oxfmt --check`: passed.
- Root reported the initial 87 Host tests passed in an unrestricted environment. New
  candidate/profile tests must be rerun by root after the source freeze; this worker does not claim
  a post-freeze full-matrix result.

## Truthful issues and limits

- `cua-desktop-session-source.mjs` max-lines is a Stop worker change made this turn, not an
  unrelated pre-existing failure. The frozen generated-evidence max-lines is a separate archive.
  This candidate builder/profile work removed its own max-lines suppressions rather than bypassing
  the repository rule.
- Formal manifest preparation could not be exercised in this worker environment: the local
  self-signed identity is untrusted (`CSSMERR_TP_NOT_TRUSTED`) and no signing identity is present.
- No app was rebuilt, copied, launched, signed, installed, or used for TCC/capture in the latest
  packaging fix. Helper identity tests use synthetic Mach-O/plist fixtures; they prove the assembly
  rewrite, not a real Electron launch.
- Root unified logs found the prior SIGTRAP cause was `Unable to find helper app`; that is separate
  from the ASAR metadata defect. Candidate `fuse4EnableEmbeddedAsarIntegrityValidation` was observed
  as ASCII `48` (false), so this ASAR metadata fix is necessary for a valid ship contract but is not
  claimed as the cause of that crash.
- Only arm64 / macOS 26.6.2 is tested. No signing, install, TCC, UI activation, or real capture was
  performed here.
- Ordinary Host origin remains untrusted transport; Host IDs are routing only. Task-time/live-task
  provider configuration changes are not guarded and full CLI compatibility is not proven.
- CA configuration is represented by a path digest only, not a CA file-content pin.
