#import <Foundation/Foundation.h>
#import <CoreGraphics/CoreGraphics.h>
int main(int argc, const char** argv) {
 @autoreleasepool {
  if (argc != 3) return 2;
  int pid = atoi(argv[1]); NSString* title = [NSString stringWithUTF8String:argv[2]];
  if (pid <= 0 || title.length == 0) return 2;
  CFArrayRef raw = CGWindowListCopyWindowInfo(kCGWindowListOptionOnScreenOnly | kCGWindowListExcludeDesktopElements, kCGNullWindowID);
  if (raw == nullptr) return 3;
  NSArray* windows = CFBridgingRelease(raw); NSMutableArray* matches = [NSMutableArray array];
  for (NSDictionary* w in windows) {
   if ([w[(id)kCGWindowOwnerPID] intValue] != pid) continue;
   if (![w[(id)kCGWindowName] isEqualToString:title]) continue;
   [matches addObject:@{@"pid":w[(id)kCGWindowOwnerPID], @"windowId":w[(id)kCGWindowNumber], @"title":w[(id)kCGWindowName], @"bounds":w[(id)kCGWindowBounds], @"layer":w[(id)kCGWindowLayer]}];
  }
  NSData* data = [NSJSONSerialization dataWithJSONObject:@{@"matches":matches} options:NSJSONWritingPrettyPrinted error:nil];
  fwrite(data.bytes,1,data.length,stdout); fputc('\n',stdout);
  return matches.count == 1 ? 0 : 4;
 }
}
