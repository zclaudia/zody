#import <Foundation/Foundation.h>
#import <Security/Security.h>
#include <cstdio>
#include <cstdlib>
int main(int argc,char**argv){ @autoreleasepool {
 if(argc!=3)return 2; pid_t pid=(pid_t)strtol(argv[1],nullptr,10); SecCodeRef code=nullptr;
 NSDictionary*attrs=@{(__bridge NSString*)kSecGuestAttributePid:@(pid)};
 OSStatus guest=SecCodeCopyGuestWithAttributes(nullptr,(__bridge CFDictionaryRef)attrs,kSecCSDefaultFlags,&code);
 if(guest!=errSecSuccess){fprintf(stderr,"guest=%d\n",(int)guest);return 3;}
 SecRequirementRef req=nullptr; OSStatus parsed=SecRequirementCreateWithString((__bridge CFStringRef)[NSString stringWithUTF8String:argv[2]],kSecCSDefaultFlags,&req);
 OSStatus valid=parsed==errSecSuccess?SecCodeCheckValidity(code,kSecCSStrictValidate,req):parsed;
 CFDictionaryRef raw=nullptr;OSStatus infoStatus=SecCodeCopySigningInformation(code,kSecCSSigningInformation|kSecCSDynamicInformation,&raw);
 if(infoStatus!=errSecSuccess){CFRelease(code);if(req)CFRelease(req);return 4;}
 NSDictionary*info=(__bridge NSDictionary*)raw;NSData*hash=info[(__bridge NSString*)kSecCodeInfoUnique];NSMutableString*hex=[NSMutableString string];
 for(NSUInteger i=0;i<hash.length;i++)[hex appendFormat:@"%02x",((const unsigned char*)hash.bytes)[i]];
 NSDictionary*ent=info[(__bridge NSString*)kSecCodeInfoEntitlementsDict];
 NSDictionary*out=@{@"pid":@(pid),@"guestStatus":@(guest),@"requirementStatus":@(valid),@"identifier":info[(__bridge NSString*)kSecCodeInfoIdentifier]?:@"",@"cdhash":hex,@"flags":info[(__bridge NSString*)kSecCodeInfoFlags]?:@0,@"entitlementCount":@(ent.count)};
 NSData*j=[NSJSONSerialization dataWithJSONObject:out options:NSJSONWritingPrettyPrinted error:nil];fwrite(j.bytes,1,j.length,stdout);puts("");
 CFRelease(raw);CFRelease(code);if(req)CFRelease(req);return valid==errSecSuccess?0:5;
}}
