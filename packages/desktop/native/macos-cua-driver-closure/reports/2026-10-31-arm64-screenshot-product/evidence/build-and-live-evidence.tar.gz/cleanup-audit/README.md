# 2026-10-31 实验构建缓存清理

仅清理 publisher-drain 与 stop-retire-reservation 的 Rust target 增量、fingerprint、.o/.rlib/.rmeta/.d 缓存。保留全部最终二进制、动态库、native 静态库、cargo-home、源码、报告、fixtures、原始证据及 2026-10-25 归档。未运行历史测试、未改产品代码或实验结论。

清理前后的全部保留文件逐项核对内容 SHA256、模式与符号链接；结果见 summary.json。四个报告引用的最终 binary/cdylib 摘要在 protected-files-before.json 与 summary.json 可复核。cleanup-plan.json 记录删除文件、尺寸和操作前身份；不是可直接重复执行的脚本。后续构建需重建被清理的中间产物。
