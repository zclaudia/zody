from pathlib import Path
import sys,json,hashlib,shutil,difflib,tarfile,datetime,subprocess
repo=Path.cwd(); root=repo/"output/cua-arm64-screenshot-product"; prior=repo/"output/cua-arm64-screenshot/frozen-arm64-screenshot-final"; out=root/"frozen-product-final"; assert not out.exists()
old=json.loads((prior/"source-sha256.json").read_text()); paths=set(old)
paths.update(["packages/desktop/scripts/macos-asar-integrity.mjs","packages/desktop/test/macosAsarIntegrity.test.ts","packages/desktop/test/normalHostCandidateIdentity.test.ts","packages/desktop/test/normalHostCandidateManifest.test.ts","packages/services/src/zcode-agent/cuaNativeAuditLog.ts","packages/services/test/cuaNativeAuditLog.test.ts"])
for name in sys.argv[1:]:
 evidence=json.loads((root/name/"build-evidence/inputs.json").read_text())
 for build in evidence["builds"].values():
  for item in build["inputs"]:
   p=item["path"]
   if not p.startswith(("node_modules/", "<")):
    assert (repo/p).is_file(),p; paths.add(p)
manifest={}; changed=[]; patches=[]
for p in sorted(paths):
 source=repo/p; assert source.is_file(),p; data=source.read_bytes();h=hashlib.sha256(data).hexdigest();manifest[p]=h;dest=out/"source"/p;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,dest)
 if old.get(p)!=h:
  before=(prior/"source"/p).read_bytes() if p in old else b"";changed.append({"path":p,"beforeSha256":old.get(p),"afterSha256":h})
  patches.extend(difflib.unified_diff(before.decode().splitlines(True),data.decode().splitlines(True),fromfile="a/"+p if p in old else "/dev/null",tofile="b/"+p))
(out/"source-sha256.json").write_text(json.dumps(manifest,indent=2)+"\n");(out/"incremental.patch").write_text("".join(patches));(out/"change-index.json").write_text(json.dumps(changed,indent=2)+"\n")
sha=hashlib.sha256((out/"source-sha256.json").read_bytes()).hexdigest()
facts={"createdAt":datetime.datetime.now(datetime.timezone.utc).isoformat(),"sourceFileCount":len(manifest),"sourceManifestSha256":sha,"meaning":"source-file manifest SHA256, not Rust frozen-tree hash","priorManifestSha256":hashlib.sha256((prior/"source-sha256.json").read_bytes()).hexdigest(),"incrementalChangedOrAdded":len(changed),"buildEvidenceCandidates":sys.argv[1:],"head":subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip()}
(out/"freeze-facts.json").write_text(json.dumps(facts,indent=2)+"\n")
archive=root/"source-and-patch-product-final.tar.gz";assert not archive.exists()
with tarfile.open(archive,"w:gz") as t:
 for p in sorted(out.rglob("*")):
  if p.is_file():t.add(p,arcname=str(p.relative_to(out)),recursive=False)
facts["archiveSha256"]=hashlib.sha256(archive.read_bytes()).hexdigest();facts["archiveBytes"]=archive.stat().st_size;(root/"final-source-archive-facts.json").write_text(json.dumps(facts,indent=2)+"\n");print(json.dumps(facts,indent=2))
