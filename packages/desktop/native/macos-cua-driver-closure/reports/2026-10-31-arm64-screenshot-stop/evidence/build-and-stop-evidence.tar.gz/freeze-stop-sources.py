from pathlib import Path
import json,hashlib,shutil,difflib,tarfile,datetime
repo=Path.cwd();out=repo/"output/cua-arm64-screenshot-stop-2026-10-31";prior=repo/"output/cua-arm64-screenshot-product/frozen-product-final";dest=out/"frozen-stop-final";assert not dest.exists()
old=json.loads((prior/"source-sha256.json").read_text());new={};changes=[];patch=[]
allowed={"specs/computer-use-macos-phase1.md","docs/plans/computer-use-macos-phase1-arm64-screenshot.md"}
for name,before in sorted(old.items()):
 data=(repo/name).read_bytes();after=hashlib.sha256(data).hexdigest();new[name]=after
 if before!=after:
  assert name in allowed,name;changes.append({"path":name,"beforeSha256":before,"afterSha256":after});patch.extend(difflib.unified_diff((prior/"source"/name).read_text().splitlines(True),data.decode().splitlines(True),fromfile="a/"+name,tofile="b/"+name))
 target=dest/"source"/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(repo/name,target)
assert {x["path"] for x in changes}==allowed,changes
(dest/"source-sha256.json").write_text(json.dumps(new,indent=2)+"\n");(dest/"status-update.patch").write_text("".join(patch));(dest/"change-index.json").write_text(json.dumps(changes,indent=2)+"\n")
shutil.copy2(prior/"incremental.patch",dest/"prior-product-implementation.patch")
facts={"createdAt":datetime.datetime.now(datetime.timezone.utc).isoformat(),"sourceFileCount":len(new),"sourceManifestSha256":hashlib.sha256((dest/"source-sha256.json").read_bytes()).hexdigest(),"sourceManifestMeaning":"source-file index SHA256, not Rust frozen-tree hash","priorManifestSha256":hashlib.sha256((prior/"source-sha256.json").read_bytes()).hexdigest(),"changedFiles":changes,"implementationChangesThisTurn":False}
(dest/"freeze-facts.json").write_text(json.dumps(facts,indent=2)+"\n")
archive=out/"source-and-patch-stop-final.tar.gz"
with tarfile.open(archive,"w:gz") as t:
 for p in sorted(dest.rglob("*")):
  if p.is_file():t.add(p,arcname=str(p.relative_to(dest)),recursive=False)
bad=[];seen=set()
with tarfile.open(archive,"r:gz") as t:
 for m in t.getmembers():
  if m.name.startswith("source/") and m.isfile():
   name=m.name[7:];seen.add(name)
   if name not in new or hashlib.sha256(t.extractfile(m).read()).hexdigest()!=new[name]:bad.append(name)
assert len(seen)==len(new) and not bad,(len(seen),bad)
facts.update(sourceArchiveSha256=hashlib.sha256(archive.read_bytes()).hexdigest(),sourceArchiveBytes=archive.stat().st_size,sourceArchiveMembersVerified=len(seen),archiveMismatches=bad)
(out/"final-source-archive-facts.json").write_text(json.dumps(facts,indent=2)+"\n");print(json.dumps(facts,indent=2))
