import { existsSync, readFileSync } from "node:fs";
import { readFile } from "node:fs/promises";
import { homedir } from "node:os";
import { join, resolve } from "node:path";
import {
  atomicWritePrivateTextFile,
  backupCorruptFile,
  readStoredCredentialSecretSync,
  resolveStoredCredentialSecret,
  withFileLock,
} from "@zcode/shared/node";
import { ZCODE_DATA_ROOT_DIR_NAME } from "@zcode/shared";
import {
  createZCodeCredentialCipher,
  isEncryptedZCodeCredentialValue,
  type ZCodeCredentialCipher,
} from "./credential-cipher.js";

const ZCODE_DATA_BASE_DIR_ENV_KEY = "ZCODE_DATA_BASE_DIR";
const CREDENTIAL_SECRET_ENV_KEY = "ZCODE_CREDENTIAL_SECRET";
const credentialChangeListeners = new Map<string, Set<() => void | Promise<void>>>();

// fork（F4.9）：`oauth:*`、`oauth:zai:*`、`oauth:bigmodel:*` 与 `zcodejwttoken` 等
// Coding Plan 账号键随 CLI 登录链删除；存量 credentials.json 中的旧键保持原样且不再读取，
// 不主动重写用户文件（同步友好）。MCP OAuth 使用独立的 key prefix，通用凭据库行为不变。

export interface SharedZCodeCredentialStoreOptions {
  baseDir?: string;
  cipher?: ZCodeCredentialCipher;
  env?: Record<string, string | undefined>;
  filePath?: string;
}

export interface SharedZCodeCredentialStore {
  readonly filePath: string;
  delete(key: string): Promise<void>;
  deleteIfValue(key: string, expectedValue: string): Promise<boolean>;
  deleteIfValues(
    expectedValues: Readonly<Record<string, string>>,
  ): Promise<Record<string, boolean>>;
  deleteManyIfValue(
    guardKey: string,
    expectedGuardValue: string,
    keysToDelete: readonly string[],
  ): Promise<boolean>;
  load(key: string): Promise<string | null>;
  loadMany(keys: readonly string[]): Promise<Record<string, string | null>>;
  onDidChange?(listener: () => void | Promise<void>): () => void;
  save(key: string, value: string): Promise<void>;
  saveMany(entries: Readonly<Record<string, string>>): Promise<void>;
  saveReplacing(key: string, value: string, replacedKeys: readonly string[]): Promise<void>;
}

export function createSharedZCodeCredentialStore(
  options: SharedZCodeCredentialStoreOptions = {},
): SharedZCodeCredentialStore {
  const env = options.env ?? process.env;
  const filePath = resolveSharedZCodeCredentialsPath(options);
  const getCipher = async () => {
    if (options.cipher) return options.cipher;
    const secret = await resolveStoredCredentialSecret(filePath, env);
    return createZCodeCredentialCipher({ env: { [CREDENTIAL_SECRET_ENV_KEY]: secret } });
  };

  return {
    filePath,

    async delete(key: string): Promise<void> {
      const validatedKey = validateCredentialKey(key);
      await mutateRawCredentialRecord(filePath, async (rawCredentials) => {
        delete rawCredentials[validatedKey];
      });
    },

    async deleteIfValue(key: string, expectedValue: string): Promise<boolean> {
      const validatedKey = validateCredentialKey(key);
      const validatedExpectedValue = validateCredentialValue(expectedValue);
      let deleted = false;
      await mutateRawCredentialRecord(filePath, async (rawCredentials) => {
        const encryptedValue = rawCredentials[validatedKey];
        if (
          encryptedValue === undefined ||
          (await decryptValue(encryptedValue, getCipher)) !== validatedExpectedValue
        ) {
          return;
        }
        delete rawCredentials[validatedKey];
        deleted = true;
      });
      return deleted;
    },

    async deleteIfValues(
      expectedValues: Readonly<Record<string, string>>,
    ): Promise<Record<string, boolean>> {
      const validatedEntries = Object.entries(expectedValues).map(
        ([key, value]) => [validateCredentialKey(key), validateCredentialValue(value)] as const,
      );
      if (validatedEntries.length === 0) return {};
      const deleted: Record<string, boolean> = {};
      await mutateRawCredentialRecord(filePath, async (rawCredentials) => {
        for (const [key, expectedValue] of validatedEntries) {
          const encryptedValue = rawCredentials[key];
          const matches =
            encryptedValue !== undefined &&
            (await decryptValue(encryptedValue, getCipher)) === expectedValue;
          deleted[key] = matches;
          if (matches) delete rawCredentials[key];
        }
      });
      return deleted;
    },

    /**
     * 条件事务：`guardKey` 当前值与期望值相等才删除 `keysToDelete` 全部 key，否则一个都不删。
     *
     * `deleteIfValues` 是逐 key 比较、逐 key 删除，无法表达「canonical generation 匹配
     * 才整体失效」——canonical 比较失败时 legacy 镜像仍可能被删掉，反之亦然。OAuth 凭据失效必须
     * 是整对的：stale 事务不能删掉 winner 的 canonical，也不能只删掉它的一半镜像。
     */
    async deleteManyIfValue(
      guardKey: string,
      expectedGuardValue: string,
      keysToDelete: readonly string[],
    ): Promise<boolean> {
      const validatedGuardKey = validateCredentialKey(guardKey);
      const validatedExpectedValue = validateCredentialValue(expectedGuardValue);
      const validatedKeys = keysToDelete.map(validateCredentialKey);
      let deleted = false;
      await mutateRawCredentialRecord(filePath, async (rawCredentials) => {
        const encryptedGuard = rawCredentials[validatedGuardKey];
        if (
          encryptedGuard === undefined ||
          (await decryptValue(encryptedGuard, getCipher)) !== validatedExpectedValue
        ) {
          return;
        }
        for (const key of validatedKeys) delete rawCredentials[key];
        deleted = true;
      });
      return deleted;
    },

    async load(key: string): Promise<string | null> {
      const rawCredentials = await readRawCredentialRecord(filePath);
      const rawValue = rawCredentials[validateCredentialKey(key)];
      if (rawValue === undefined) {
        return null;
      }
      return decryptValue(rawValue, getCipher);
    },

    async loadMany(keys: readonly string[]): Promise<Record<string, string | null>> {
      const validatedKeys = keys.map(validateCredentialKey);
      const rawCredentials = await readRawCredentialRecord(filePath);
      return Object.fromEntries(
        await Promise.all(
          validatedKeys.map(async (key) => {
            const rawValue = rawCredentials[key];
            return [key, rawValue === undefined ? null : await decryptValue(rawValue, getCipher)];
          }),
        ),
      );
    },

    onDidChange(listener: () => void | Promise<void>): () => void {
      let listeners = credentialChangeListeners.get(filePath);
      if (!listeners) {
        listeners = new Set();
        credentialChangeListeners.set(filePath, listeners);
      }
      listeners.add(listener);
      return () => {
        listeners?.delete(listener);
        if (listeners?.size === 0) credentialChangeListeners.delete(filePath);
      };
    },

    async save(key: string, value: string): Promise<void> {
      const validatedKey = validateCredentialKey(key);
      const encryptedValue = (await getCipher()).encrypt(validateCredentialValue(value));
      await mutateRawCredentialRecord(filePath, (rawCredentials) => {
        rawCredentials[validatedKey] = encryptedValue;
      });
    },

    async saveMany(entries: Readonly<Record<string, string>>): Promise<void> {
      const cipher = await getCipher();
      const encryptedEntries = Object.entries(entries).map(
        ([key, value]) =>
          [validateCredentialKey(key), cipher.encrypt(validateCredentialValue(value))] as const,
      );
      await mutateRawCredentialRecord(filePath, (rawCredentials) => {
        for (const [key, encryptedValue] of encryptedEntries) {
          rawCredentials[key] = encryptedValue;
        }
      });
    },

    async saveReplacing(
      key: string,
      value: string,
      replacedKeys: readonly string[],
    ): Promise<void> {
      const validatedKey = validateCredentialKey(key);
      const encryptedValue = (await getCipher()).encrypt(validateCredentialValue(value));
      const validatedReplacedKeys = replacedKeys.map(validateCredentialKey);
      await mutateRawCredentialRecord(filePath, (rawCredentials) => {
        rawCredentials[validatedKey] = encryptedValue;
        for (const replacedKey of validatedReplacedKeys) {
          if (replacedKey !== validatedKey) delete rawCredentials[replacedKey];
        }
      });
    },
  };
}

export function loadSharedZCodeCredentialSync(
  key: string,
  options: SharedZCodeCredentialStoreOptions = {},
): string | undefined {
  const filePath = resolveSharedZCodeCredentialsPath(options);
  if (!existsSync(filePath)) {
    return undefined;
  }

  try {
    const raw = readFileSync(filePath, "utf-8");
    const parsed = JSON.parse(raw);
    const record = parseCredentialRecord(parsed);
    const rawValue = record[validateCredentialKey(key)];
    if (rawValue === undefined) {
      return undefined;
    }
    const decrypted = isEncryptedZCodeCredentialValue(rawValue)
      ? (
          options.cipher ??
          createZCodeCredentialCipher({
            env: {
              [CREDENTIAL_SECRET_ENV_KEY]: readStoredCredentialSecretSync(filePath, options.env),
            },
          })
        ).decrypt(rawValue)
      : rawValue;
    return decrypted.trim().length > 0 ? decrypted : undefined;
  } catch {
    return undefined;
  }
}

export function resolveSharedZCodeCredentialsPath(
  options: SharedZCodeCredentialStoreOptions = {},
): string {
  if (options.filePath) {
    return resolveUserPath(options.filePath);
  }

  const env = options.env ?? process.env;
  const baseDir = options.baseDir ?? env[ZCODE_DATA_BASE_DIR_ENV_KEY] ?? homedir();
  // fork 数据隔离：家目录级数据根改为 .zody，避免与正式版 ZCode 共用。
  return join(resolveUserPath(baseDir), ZCODE_DATA_ROOT_DIR_NAME, "v2", "credentials.json");
}

async function readRawCredentialRecord(filePath: string): Promise<Record<string, string>> {
  let raw: string;
  try {
    raw = await readFile(filePath, "utf-8");
  } catch (error) {
    if (getErrorCode(error) === "ENOENT") {
      return {};
    }
    throw new Error(`Unable to read shared Zody credentials: ${filePath}`, { cause: error });
  }

  try {
    return parseCredentialRecord(JSON.parse(raw));
  } catch (error) {
    // 损坏的凭据文件若被当成空对象继续保存，会一次性抹掉其他进程的全部凭据。
    // 先保留现场再失败，调用方必须显式处理恢复，不能静默覆盖。
    const backupPath = await backupCorruptFile(filePath).catch(() => undefined);
    const evidence = backupPath ? ` Backup: ${backupPath}` : "";
    throw new Error(`Shared Zody credentials are corrupt: ${filePath}.${evidence}`, {
      cause: error,
    });
  }
}

async function mutateRawCredentialRecord(
  filePath: string,
  mutation: (value: Record<string, string>) => void | Promise<void>,
): Promise<void> {
  // CLI、设置页和 session 可能位于不同 Node 进程；锁必须覆盖完整的
  // read-modify-write，单独原子 rename 只能防半写，不能防旧快照覆盖新 key。
  await withFileLock(filePath, async () => {
    const value = await readRawCredentialRecord(filePath);
    await mutation(value);
    await atomicWritePrivateTextFile(filePath, `${JSON.stringify(value, null, 2)}\n`);
  });
  const listeners = [...(credentialChangeListeners.get(filePath) ?? [])];
  // 同进程的 Registry Source 需要在登录返回前观察到新凭据；单个监听者失败不应
  // 把已经原子落盘的 Credential 伪装成写入失败。
  await Promise.allSettled(listeners.map((listener) => listener()));
}

async function decryptValue(
  value: string,
  getCipher: () => Promise<ZCodeCredentialCipher>,
): Promise<string> {
  return isEncryptedZCodeCredentialValue(value) ? (await getCipher()).decrypt(value) : value;
}

function parseCredentialRecord(value: unknown): Record<string, string> {
  if (!isRecord(value)) {
    throw new Error("Credential record must be an object");
  }

  const result: Record<string, string> = {};
  for (const [key, entry] of Object.entries(value)) {
    if (typeof entry !== "string") {
      throw new Error(`Credential record value must be a string: ${key}`);
    }
    result[key] = entry;
  }
  return result;
}

function getErrorCode(error: unknown): string | undefined {
  if (typeof error !== "object" || error === null || !("code" in error)) {
    return undefined;
  }
  const code = (error as { code?: unknown }).code;
  return typeof code === "string" ? code : undefined;
}

function validateCredentialKey(key: string): string {
  const trimmed = key.trim();
  if (trimmed.length === 0) {
    throw new Error("Credential key must not be empty");
  }
  return trimmed;
}

function validateCredentialValue(value: string): string {
  if (value.length === 0) {
    throw new Error("Credential value must not be empty");
  }
  return value;
}

function resolveUserPath(value: string): string {
  if (value === "~") {
    return homedir();
  }
  if (value.startsWith("~/")) {
    return join(homedir(), value.slice(2));
  }
  return resolve(value);
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
