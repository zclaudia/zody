import { spawn, type ChildProcess, type SpawnOptions } from "node:child_process";
import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import type { Writable } from "node:stream";
import { fileURLToPath } from "node:url";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { buildNodeReplHostBundle } from "../../node-repl-host/scripts/build.mjs";
import {
  buildControlOnlyChildEnvironment,
  resolveOfficialControlOnlyLauncher,
  startControlOnlyDiagnosticLauncher,
  ZCODE_NODE_REPL_CONTROL_FLAG,
  type ControlOnlyLauncherClosedEvent,
} from "../src/mcp/control-only-launcher.js";

const buildTimeoutMs = 120_000;
const waitTimeoutMs = 15_000;

async function withTimeout<T>(promise: Promise<T>, message: string): Promise<T> {
  let timer: NodeJS.Timeout | undefined;
  try {
    return await Promise.race([
      promise,
      new Promise<never>((_resolve, reject) => {
        timer = setTimeout(() => reject(new Error(message)), waitTimeoutMs);
        timer.unref?.();
      }),
    ]);
  } finally {
    if (timer) clearTimeout(timer);
  }
}

function createBootstrapCapturingSpawn(): {
  spawn: (command: string, args: readonly string[], options: SpawnOptions) => ChildProcess;
  bootstrap: () => string;
} {
  let captured = "";
  return {
    spawn: (command, args, options) => {
      const child = spawn(command, [...args], options);
      const stdio = [...child.stdio];
      const writer = stdio[3] as Writable;
      stdio[3] = new Proxy(writer, {
        get(target, property) {
          if (property === "write") {
            return (chunk: string | Buffer, ...rest: unknown[]) => {
              captured += typeof chunk === "string" ? chunk : chunk.toString("utf8");
              return (target.write as (...args: unknown[]) => boolean)(chunk, ...rest);
            };
          }
          if (property === "end") {
            return (chunk?: string | Buffer, ...rest: unknown[]) => {
              if (chunk !== undefined) {
                captured += typeof chunk === "string" ? chunk : chunk.toString("utf8");
              }
              return (target.end as (...args: unknown[]) => Writable)(chunk, ...rest);
            };
          }
          const value = Reflect.get(target, property, target);
          return typeof value === "function" ? value.bind(target) : value;
        },
      }) as Writable;
      Object.defineProperty(child, "stdio", { configurable: true, value: stdio });
      return child;
    },
    bootstrap: () => captured,
  };
}

describe("control-only diagnostic launcher", () => {
  let directory = "";
  let serverPath = "";
  let cliEntryPath = "";
  let tsxLoaderPath = "";

  beforeAll(async () => {
    directory = await mkdtemp(join(tmpdir(), "zcode-control-launcher-"));
    const built = await buildNodeReplHostBundle({ outfile: join(directory, "mcp", "server.mjs") });
    serverPath = built.outfile;
    cliEntryPath = resolve(import.meta.dirname, "../../cli/src/main.ts");
    tsxLoaderPath = fileURLToPath(import.meta.resolve("tsx"));
  }, buildTimeoutMs);

  afterAll(async () => {
    if (directory) await rm(directory, { force: true, recursive: true });
  });

  it("builds a trusted environment without loader, path override, or credential variables", () => {
    const env = buildControlOnlyChildEnvironment({
      PATH: "/usr/bin",
      HOME: "/home/test",
      NODE_OPTIONS: "--inspect=0.0.0.0:9229",
      NODE_PATH: "/tmp/modules",
      NODE_DEBUG: "net",
      ZCODE_CUA_PERMISSION_BROKER_TOKEN: "secret-token",
      ZCODE_PLUGIN_ID: "computer-use@zcode-plugins-official",
      ELECTRON_RUN_AS_NODE: "1",
    });

    expect(env).toEqual({
      PATH: "/usr/bin",
      HOME: "/home/test",
      ELECTRON_RUN_AS_NODE: "1",
    });
  });

  it("resolves the official plugin-host launcher argument order", () => {
    const launch = resolveOfficialControlOnlyLauncher({
      cliEntryPath,
      cliPrefixArgs: ["--import", tsxLoaderPath],
      execPath: process.execPath,
      serverPath,
    });
    expect(launch.command).toBe(process.execPath);
    expect(launch.args).toEqual([
      "--import",
      tsxLoaderPath,
      cliEntryPath,
      "__zcode-plugin-host",
      serverPath,
      ZCODE_NODE_REPL_CONTROL_FLAG,
    ]);
  });

  it(
    "spawns the real official plugin host and node_repl bundle, then applies signed revoke/stop",
    async () => {
      const launch = resolveOfficialControlOnlyLauncher({
        cliEntryPath,
        cliPrefixArgs: ["--import", tsxLoaderPath],
        execPath: process.execPath,
        serverPath,
      });
      const capture = createBootstrapCapturingSpawn();
      const closedEvents: ControlOnlyLauncherClosedEvent[] = [];
      const launcher = await withTimeout(
        startControlOnlyDiagnosticLauncher({
          appIncarnation: "app-control-launcher-test",
          launch,
          onClosed: (event) => {
            closedEvents.push(event);
          },
          requestTimeoutMs: 5_000,
          spawn: capture.spawn,
          startupTimeoutMs: 30_000,
        }),
        "launcher did not become ready",
      );

      try {
        const binding = { ...launcher.binding };
        expect(Object.keys(binding).sort()).toEqual([
          "appIncarnation",
          "channelId",
          "controllerIncarnation",
          "producerIncarnation",
        ]);
        expect(JSON.stringify(binding)).not.toContain("private");
        expect("privateKey" in launcher).toBe(false);

        const bootstrap = JSON.parse(capture.bootstrap().trim()) as {
          producerPrivateKeyPkcs8: string;
        };
        expect(bootstrap.producerPrivateKeyPkcs8.length).toBeGreaterThan(32);
        expect(JSON.stringify(launch.args)).not.toContain(bootstrap.producerPrivateKeyPkcs8);
        const env = buildControlOnlyChildEnvironment(process.env);
        expect(Object.values(env)).not.toContain(bootstrap.producerPrivateKeyPkcs8);

        const revoke = await launcher.request({
          operation: "revoke_submission",
          submissionLineageId: "lineage-launcher-test",
          authorizationRevision: 1,
        });
        expect(revoke.ack.body.phase).toBe("revoked");
        expect(revoke.evaluation.revoked).toMatchObject({
          authorizationRevoked: true,
          complete: true,
        });

        const stop = await launcher.request({
          operation: "stop",
          submissionLineageId: "lineage-launcher-test",
          authorizationRevision: 2,
        });
        expect(stop.ack.body.phase).toBe("stop_pending");
        expect(stop.ack.body.phase).not.toBe("fenced");
        expect(stop.ack.body.phase).not.toBe("drained");
        expect(stop.evaluation.stop).toMatchObject({
          complete: false,
          leaseReleased: false,
          nativeFenced: false,
          ownedInputsReleased: false,
          pending: true,
        });
      } finally {
        const firstClose = launcher.close();
        const secondClose = launcher.close();
        expect(secondClose).toBe(firstClose);
        await withTimeout(firstClose, "launcher did not close");
      }

      expect(closedEvents).toHaveLength(1);
      expect(closedEvents[0]).toMatchObject({
        reason: "disposed",
        exitCode: 0,
        signal: null,
      });
      expect(JSON.stringify(closedEvents[0])).not.toContain("privateKey");
      await expect(
        launcher.request({
          operation: "revoke_submission",
          submissionLineageId: "lineage-after-close",
          authorizationRevision: 1,
        }),
      ).rejects.toMatchObject({ code: "closed" });
    },
    buildTimeoutMs,
  );

  it("reports startup exit as failure once and never resolves a launcher", async () => {
    const sentinel = "STARTUP_STDERR_SENTINEL_SHOULD_NOT_ECHO";
    const closedEvents: ControlOnlyLauncherClosedEvent[] = [];
    await expect(
      startControlOnlyDiagnosticLauncher({
        appIncarnation: "app-startup-failure",
        launch: {
          args: ["-e", `process.stderr.write(${JSON.stringify(sentinel)}); process.exit(2);`],
          command: process.execPath,
        },
        onClosed: (event) => {
          closedEvents.push(event);
        },
        startupTimeoutMs: 5_000,
      }),
    ).rejects.toMatchObject({ code: "startup_failed" });

    expect(closedEvents).toHaveLength(1);
    expect(closedEvents[0]).toMatchObject({ reason: "startup_failed", exitCode: 2 });
    expect(JSON.stringify(closedEvents[0])).not.toContain(sentinel);
  });

  it("fails closed on a startup deadline and still performs observable cleanup", async () => {
    const closedEvents: ControlOnlyLauncherClosedEvent[] = [];
    await expect(
      startControlOnlyDiagnosticLauncher({
        appIncarnation: "app-startup-timeout",
        closeTimeoutMs: 250,
        launch: { args: ["-e", "setInterval(() => {}, 1000);"], command: process.execPath },
        onClosed: (event) => {
          closedEvents.push(event);
        },
        startupTimeoutMs: 100,
      }),
    ).rejects.toMatchObject({ code: "startup_timeout" });

    expect(closedEvents).toHaveLength(1);
    expect(closedEvents[0]?.reason).toBe("startup_failed");
    expect(closedEvents[0]?.message).not.toContain("setInterval");
  });

  it("turns spawn errors into a settled startup failure", async () => {
    const closedEvents: ControlOnlyLauncherClosedEvent[] = [];
    await expect(
      startControlOnlyDiagnosticLauncher({
        appIncarnation: "app-spawn-error",
        launch: {
          args: [],
          command: join(directory, "missing-control-launcher"),
        },
        onClosed: (event) => {
          closedEvents.push(event);
        },
        startupTimeoutMs: 1_000,
      }),
    ).rejects.toMatchObject({ code: "startup_failed" });
    expect(closedEvents).toHaveLength(1);
    expect(closedEvents[0]?.exitCode).toBeNull();
  });
});
