import type { ChildProcess } from "node:child_process";
import type { ControlChannelCloseCode } from "@zcode/zcode-cua/control-channel";
import {
  ControlOnlyLauncherError,
  type ControlOnlyLauncherCloseReason,
  type ControlOnlyLauncherClosedEvent,
} from "./control-only-contract.js";

export interface ExitInfo {
  readonly code: number | null;
  readonly signal: NodeJS.Signals | null;
}

export function withTimeout<T>(promise: Promise<T>, timeoutMs: number): Promise<T | null> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => resolve(null), timeoutMs);
    timer.unref?.();
    promise.then(
      (value) => {
        clearTimeout(timer);
        resolve(value);
      },
      (error) => {
        clearTimeout(timer);
        reject(error);
      },
    );
  });
}

export function destroyStdio(child: ChildProcess | null): void {
  if (!child) return;
  for (const index of [3, 4, 5, 6]) {
    const stream = child.stdio[index];
    if (stream && !stream.destroyed) {
      try {
        stream.destroy();
      } catch {
        // Cleanup continues with the remaining private fds.
      }
    }
  }
  for (const stream of [child.stdout, child.stderr]) {
    if (stream && !stream.destroyed) {
      try {
        stream.destroy();
      } catch {
        // Diagnostic pipes are best effort once the child is closing.
      }
    }
  }
}

export function mapChannelClose(code: ControlChannelCloseCode): ControlOnlyLauncherCloseReason {
  switch (code) {
    case "disposed":
    case "local_close":
    case "peer_eof":
    case "transport_closed":
      return code;
    case "transport_error":
      return "transport_error";
    case "protocol_error":
    case "frame_too_large":
    case "outbound_overflow":
    case "incoming_overflow":
    case "handler_error":
      return "protocol_error";
    case "request_timeout":
      return "request_timeout";
    case "request_aborted":
      return "transport_closed";
  }
}

export function normalizeStartupError(error: unknown): ControlOnlyLauncherError {
  if (error instanceof ControlOnlyLauncherError) return error;
  return new ControlOnlyLauncherError("startup_failed", "control-only launcher startup failed", {
    cause: error,
  });
}

export function startupEvent(
  error: ControlOnlyLauncherError,
  exit: ExitInfo | null,
): ControlOnlyLauncherClosedEvent {
  return Object.freeze({
    cause: error,
    exitCode: exit?.code ?? null,
    message: "control-only launcher startup failed",
    pendingRequests: 0,
    reason: "startup_failed" as const,
    signal: exit?.signal ?? null,
  });
}
